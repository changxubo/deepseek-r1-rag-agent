"""Shared utilities module."""
