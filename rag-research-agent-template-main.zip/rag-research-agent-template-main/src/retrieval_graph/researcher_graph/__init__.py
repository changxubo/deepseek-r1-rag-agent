"""Researcher Graph Module."""
